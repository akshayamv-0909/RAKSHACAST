/**
 * RakshaCast - National Disaster Early Warning & Resilience Platform
 * Ministry of Earth Sciences (MoES) & India Meteorological Department (IMD)
 * 
 * Includes:
 * 1. Multi-Color Danger Radius Circles on Maps (Blue for Flood, Red for Cyclone, Purple for Lightning, Amber for Landslide)
 * 2. Distinct Citizen vs NDRF Admin Profiles
 * 3. Citizen SOS / Evacuate Routing to NDRF Admin Command (Admin-only priority notifications)
 * 4. Multi-Channel Emergency Alerts with Quiet Hours & OTP Verification
 * 5. Full-Day "Today's Weather" & 24h Hourly Nowcast Timeline
 * 6. Upcoming 7-Day Forecast with Interactive Modals
 * 7. AI Precaution Engine & Offline Caching
 */

let STATE = {
    isAuthority: false, // false = Citizen Mode, true = NDRF Admin Mode
    currentTab: "home",
    selectedLanguage: "EN",
    currentLocationName: "Haridwar-Rishikesh Valley, Uttarakhand",
    userCoords: [30.0860, 78.2690],
    inundationHour: 0,
    acousticBeaconActive: false,
    strobeActive: false,
    isOffline: !navigator.onLine,
    dataStatus: "LIVE",
    dataSource: "Live India Open-Meteo & IMD Doppler Radar Feed",
    
    // User / Citizen Profile
    citizenProfile: {
        name: "Aarav Sharma",
        phone: "+91 98765 43210",
        emergencyContact: "+91 91234 56789",
        isPhoneVerified: true,
        citizenId: "RAKSHA-IN-9842",
        bloodGroup: "O+ Positive",
        familyMembersCount: 4,
        sector: "Sector 4 Lowland Basin, Haridwar"
    },

    // NDRF Officer / Admin Profile
    adminProfile: {
        officerName: "Commander Vikram Rathore",
        badgeNumber: "NDRF-OFFICER-1092",
        battalion: "10th NDRF Battalion (Search & Rescue)",
        rank: "Incident Commander / Joint Director",
        dutySector: "Haridwar-Rishikesh Flood Ops Grid",
        unitStatus: "ACTIVE ON-DUTY",
        boatsReady: 6,
        dronesAirborne: 2
    },

    // Multi-Channel Notification Preferences
    settings: {
        inAppAlerts: true,
        pushNotifications: true,
        smsAlerts: true,
        phoneCallAlerts: true,
        quietHoursEnabled: false,
        quietHoursStart: "22:00",
        quietHoursEnd: "07:00",
        criticalBypassQuietHours: true
    },

    seenAlertHashes: new Set(),

    telemetry: {
        temperature: 27.2,
        feelsLike: 29.4,
        rainfall: 48.0,
        humidity: 86,
        windSpeed: 28,
        windDirection: "ENE (65°)",
        pressure: 994.2,
        waterLevel: 2.45,
        elevation: 325,
        riskScore: 82,
        riskLevel: "CRITICAL",
        leadTimeHours: 3.5,
        weatherCondition: "Heavy Rain & Thundershowers",
        weatherCode: 95,
        sunrise: "05:42 AM",
        sunset: "06:51 PM",
        lastUpdated: new Date().toLocaleTimeString("en-IN") + " IST"
    },

    hourlyForecast: [],
    dailyForecast: [],
    precautions: [],

    alerts: [
        {
            id: "ALT-01",
            title: "RED CRITICAL: Severe Cloudburst & Flash Flood Nowcast",
            area: "Ganga-Bagmati Basin & Lowland Corridors",
            severity: "CRITICAL",
            timeIssued: "Just now",
            instructions: "Move to designated high ridge shelters immediately. Water surge wave estimated in 3.5 hours."
        },
        {
            id: "ALT-02",
            title: "AMBER ADVISORY: Lightning & Thunderstorm Warning",
            area: "Catchment Slopes & Ridge Passages",
            severity: "HIGH",
            timeIssued: "20 mins ago",
            instructions: "Avoid open fields, tall trees, and metal structures. Keep phones charged."
        }
    ],

    alertDeliveryHistory: [
        {
            id: "DEL-901",
            alertId: "ALT-01",
            title: "RED CRITICAL: Flash Flood Nowcast",
            severity: "CRITICAL",
            timestamp: "Today, 11:15 AM",
            recipient: "+91 98765 43210",
            channels: {
                inApp: "DELIVERED",
                push: "DELIVERED (FCM)",
                sms: "DEMO_SENT (MSG91)",
                call: "DEMO_QUEUED (Exotel IVR)"
            }
        }
    ],

    shelters: [
        { id: "SH-01", name: "Temple Hill Community Relief Center", lat: 30.0780, lng: 78.2520, elevation: 445, distance: "1.4 km", available: 415, capacity: 600, status: "OPEN" },
        { id: "SH-02", name: "Govt High School Elevated Camp", lat: 30.0950, lng: 78.2580, elevation: 410, distance: "2.1 km", available: 280, capacity: 400, status: "OPEN" },
        { id: "SH-03", name: "District Indoor Sports Stadium Base Camp", lat: 30.0990, lng: 78.2800, elevation: 420, distance: "3.5 km", available: 790, capacity: 1200, status: "OPEN" }
    ],

    sosQueue: [
        {
            id: "SOS-9081",
            userName: "Aarav Sharma & Family",
            phone: "+91 98765 43210",
            emergencyType: "Rising Flood Water (Trapped 1st Floor)",
            peopleCount: 4,
            location: "Sector 4 Lowland Basin",
            lat: 30.0855,
            lng: 78.2705,
            hasInfant: true,
            hasElderly: true,
            hasMedical: true,
            message: "Water rose to 6 feet, grandmother needs oxygen cylinder.",
            triageScore: 98.5,
            status: "TEAM_EN_ROUTE",
            assignedTeam: "NDRF Bravo Alpha (Motor Boat #4)",
            time: "10 mins ago"
        }
    ],

    activeMap: null,
    evacMap: null,
    offlinePackDownloaded: true,
    familySafeStatus: [
        { name: "Me (Aarav)", status: "SAFE_AT_HOME", location: "Sector 4", battery: "84%", time: "Just now" },
        { name: "Father (Ramesh)", status: "AT_SHELTER", location: "Temple Hill Camp", battery: "62%", time: "15 mins ago" },
        { name: "Sister (Priya)", status: "SAFE_AT_WORK", location: "High Ridge Block", battery: "91%", time: "30 mins ago" }
    ],
    evacChecklist: [
        { id: 1, text: "Drinking Water (2L per person)", done: true },
        { id: 2, text: "Aadhaar Card / Essential Documents in Plastic Pouch", done: true },
        { id: 3, text: "Prescription Medicines & First Aid", done: true },
        { id: 4, text: "Charged Phone & Powerbank", done: true },
        { id: 5, text: "Emergency Torch & Whistle", done: false }
    ]
};

// Weather Mapping Helpers
const WMO_CODE_MAP = {
    0: { text: "Clear Sky", icon: "sun", risk: "Normal" },
    1: { text: "Mainly Clear", icon: "sun-medium", risk: "Normal" },
    2: { text: "Partly Cloudy", icon: "cloud-sun", risk: "Normal" },
    3: { text: "Overcast", icon: "cloud", risk: "Normal" },
    45: { text: "Fog / Mist", icon: "cloud-fog", risk: "Advisory" },
    48: { text: "Rime Fog", icon: "cloud-fog", risk: "Advisory" },
    51: { text: "Light Drizzle", icon: "cloud-drizzle", risk: "Normal" },
    53: { text: "Moderate Drizzle", icon: "cloud-drizzle", risk: "Advisory" },
    55: { text: "Dense Drizzle", icon: "cloud-rain", risk: "Advisory" },
    61: { text: "Slight Rain", icon: "cloud-rain", risk: "Normal" },
    63: { text: "Moderate Rain", icon: "cloud-rain", risk: "Advisory" },
    65: { text: "Heavy Inundating Rain", icon: "cloud-lightning", risk: "Caution" },
    71: { text: "Slight Snowfall", icon: "snowflake", risk: "Advisory" },
    75: { text: "Heavy Snowfall", icon: "snowflake", risk: "Caution" },
    80: { text: "Slight Rain Showers", icon: "cloud-rain", risk: "Normal" },
    81: { text: "Moderate Showers", icon: "cloud-rain", risk: "Advisory" },
    82: { text: "Violent Cloudburst Showers", icon: "cloud-lightning", risk: "Emergency" },
    95: { text: "Thunderstorm with High Gusts", icon: "cloud-lightning", risk: "Caution" },
    96: { text: "Severe Thunderstorm with Hail", icon: "cloud-lightning", risk: "Emergency" },
    99: { text: "Severe Thunderstorm & Lightning", icon: "zap", risk: "Emergency" }
};

function getWeatherInfo(code) {
    return WMO_CODE_MAP[code] || { text: "Precipitation Activity", icon: "cloud-rain", risk: "Advisory" };
}

// Web Audio Acoustic Search Beacon
let audioCtx = null;
let beaconInterval = null;

function toggleAcousticSearchBeacon() {
    STATE.acousticBeaconActive = !STATE.acousticBeaconActive;
    const btn = document.getElementById("acoustic-beacon-btn");
    
    if (STATE.acousticBeaconActive) {
        if (btn) btn.className = "flex-1 py-2.5 bg-red-600 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow animate-pulse";
        showToast("🔊 Acoustic Search Beacon ACTIVATED: Emitting 880Hz Sonar Pulses for Rescue Canines & Boats", "critical");
        
        beaconInterval = setInterval(() => {
            playSirenPulse();
        }, 1200);
    } else {
        if (btn) btn.className = "flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs border border-slate-300 flex items-center justify-center space-x-1.5";
        if (beaconInterval) clearInterval(beaconInterval);
        showToast("Acoustic Search Beacon Deactivated.", "info");
    }
}

function playSirenPulse() {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        if (!audioCtx) audioCtx = new AudioContext();
        
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.4);
        
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
        
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.5);
    } catch(e) {}
}

// SOS Morse Strobe
function toggleFlashlightStrobe() {
    STATE.strobeActive = !STATE.strobeActive;
    const btn = document.getElementById("strobe-btn");
    if (STATE.strobeActive) {
        if (btn) btn.className = "flex-1 py-2.5 bg-amber-600 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow animate-pulse";
        showToast("🔦 SOS Morse Strobe Active: (··· --- ···)", "success");
    } else {
        if (btn) btn.className = "flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs border border-slate-300 flex items-center justify-center space-x-1.5";
        showToast("Flashlight Strobe Deactivated.", "info");
    }
}

// =============================================================
// INITIALIZATION
// =============================================================
document.addEventListener("DOMContentLoaded", async () => {
    loadSettingsFromStorage();
    loadCachedWeather();
    
    window.addEventListener("online", () => {
        STATE.isOffline = false;
        STATE.dataStatus = "LIVE";
        showToast("🌐 Internet connection restored. Syncing live telemetry...", "success");
        fetchLiveOpenMeteo(STATE.userCoords[0], STATE.userCoords[1], STATE.currentLocationName);
    });
    window.addEventListener("offline", () => {
        STATE.isOffline = true;
        STATE.dataStatus = "OFFLINE";
        showToast("⚠️ Device is Offline. Serving cached meteorological models.", "critical");
        navigate(STATE.currentTab);
    });

    updateBottomNav();
    navigate("home");

    // Automatically detect exact real-life GPS / IP location on app launch
    detectDeviceGPS(true);

    // Periodic weather sync every 3 minutes
    setInterval(() => {
        if (!STATE.isOffline) {
            fetchLiveOpenMeteo(STATE.userCoords[0], STATE.userCoords[1], STATE.currentLocationName, true);
        }
    }, 180000);
});

// =============================================================
// REVERSE GEOCODING & REAL-LOCATION UTILITIES
// =============================================================
async function reverseGeocode(lat, lng) {
    try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14&addressdetails=1`);
        if (res.ok) {
            const data = await res.json();
            const addr = data.address || {};
            const locality = addr.suburb || addr.neighbourhood || addr.residential || addr.road || addr.village || "";
            const city = addr.city || addr.town || addr.city_district || addr.county || addr.state_district || "";
            const state = addr.state || "";
            
            const parts = [locality, city, state].filter(p => p && p.trim().length > 0);
            if (parts.length > 0) {
                return parts.join(", ");
            }
            if (data.display_name) {
                return data.display_name.split(",").slice(0, 3).join(",").trim();
            }
        }
    } catch (e) {
        console.warn("Nominatim reverse geocode fallback:", e.message);
    }
    
    try {
        const res2 = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`);
        if (res2.ok) {
            const d = await res2.json();
            const loc = [d.locality || d.city, d.principalSubdivision, d.countryName].filter(Boolean).join(", ");
            if (loc) return loc;
        }
    } catch(e) {}
    
    return `District (${lat.toFixed(3)}°N, ${lng.toFixed(3)}°E)`;
}

function updateLocalShelters(lat, lng, locName) {
    const baseLoc = locName.split(',')[0].trim();
    STATE.shelters = [
        {
            id: "SH-01",
            name: `${baseLoc} Elevated Relief Center`,
            lat: Number((lat + 0.0075).toFixed(4)),
            lng: Number((lng + 0.0085).toFixed(4)),
            elevation: Math.round(STATE.telemetry.elevation + 45),
            distance: "1.2 km",
            available: 380,
            capacity: 500,
            status: "OPEN"
        },
        {
            id: "SH-02",
            name: `${baseLoc} Govt Senior Model School Relief Hub`,
            lat: Number((lat - 0.0085).toFixed(4)),
            lng: Number((lng + 0.0115).toFixed(4)),
            elevation: Math.round(STATE.telemetry.elevation + 30),
            distance: "1.7 km",
            available: 240,
            capacity: 400,
            status: "OPEN"
        },
        {
            id: "SH-03",
            name: `${baseLoc} District Indoor Sports Complex Base Camp`,
            lat: Number((lat + 0.0135).toFixed(4)),
            lng: Number((lng - 0.0105).toFixed(4)),
            elevation: Math.round(STATE.telemetry.elevation + 55),
            distance: "2.6 km",
            available: 850,
            capacity: 1200,
            status: "OPEN"
        }
    ];
}

function updateLocalizedAlerts(telemetry, daily, locName) {
    const t = telemetry;
    const curCode = t.weatherCode;
    const alerts = [];

    if (t.riskLevel === "CRITICAL") {
        alerts.push({
            id: `ALT-${Date.now().toString().slice(-4)}`,
            title: `RED CRITICAL: Severe Inundation & Flash Flood Nowcast`,
            area: `${locName} & Lowland Catchments`,
            severity: "CRITICAL",
            timeIssued: "Just now",
            instructions: "Imminent waterlogging and river/drain surge. Move essential belongings and evacuate ground floors."
        });
    } else if (t.riskLevel === "HIGH" || curCode >= 95) {
        alerts.push({
            id: `ALT-${Date.now().toString().slice(-4)}`,
            title: `AMBER SEVERE: Convective Lightning & Thunderstorm Alert`,
            area: `${locName}`,
            severity: "HIGH",
            timeIssued: "10 mins ago",
            instructions: "Frequent cloud-to-ground lightning strokes detected. Remain indoors and unplug high-voltage electronics."
        });
    } else if (t.riskLevel === "MODERATE" || t.rainfall > 0) {
        alerts.push({
            id: `ALT-${Date.now().toString().slice(-4)}`,
            title: `YELLOW ADVISORY: Active Rainfall & Municipal Drainage Watch`,
            area: `${locName}`,
            severity: "MODERATE",
            timeIssued: "15 mins ago",
            instructions: "Continuous precipitation. Municipal storm drains under active monitoring. Drive with caution."
        });
    } else {
        alerts.push({
            id: `ALT-${Date.now().toString().slice(-4)}`,
            title: `GREEN NORMAL: Regional Weather & Readiness Watch`,
            area: `${locName}`,
            severity: "NORMAL",
            timeIssued: "Active",
            instructions: "Atmospheric indicators within normal range. Early warning sensors connected and scanning 24/7."
        });
    }

    if (t.windSpeed >= 30) {
        alerts.push({
            id: `ALT-WIND`,
            title: `CAUTION: High Gale Wind Surge (${t.windSpeed} km/h)`,
            area: `${locName} Open Corridors`,
            severity: "CAUTION",
            timeIssued: "25 mins ago",
            instructions: "Secure loose rooftop fixtures and stay clear of old trees or construction scaffolds."
        });
    }

    STATE.alerts = alerts;
}

// =============================================================
// WEATHER DATA HANDLING & PRECAUTION ENGINE
// =============================================================
async function fetchLiveOpenMeteo(lat, lng, locName, silent = false) {
    try {
        if (!locName || locName.startsWith("Sector (") || locName.startsWith("District (")) {
            locName = await reverseGeocode(lat, lng);
        }
        STATE.currentLocationName = locName;
        STATE.userCoords = [lat, lng];
        STATE.citizenProfile.sector = locName;
        STATE.adminProfile.dutySector = `${locName.split(',')[0]} Disaster Ops Sector`;

        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,precipitation_probability,precipitation,rain,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset&timezone=auto`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);

        if (res.ok) {
            const data = await res.json();
            const cur = data.current;
            const daily = data.daily;
            const hourly = data.hourly;

            if (cur) {
                STATE.telemetry.temperature = Math.round(cur.temperature_2m * 10) / 10;
                STATE.telemetry.feelsLike = Math.round((cur.apparent_temperature || cur.temperature_2m) * 10) / 10;
                STATE.telemetry.humidity = Math.round(cur.relative_humidity_2m);
                STATE.telemetry.pressure = Math.round(cur.surface_pressure * 10) / 10;
                STATE.telemetry.windSpeed = Math.round(cur.wind_speed_10m * 10) / 10;
                STATE.telemetry.windDirection = `${cur.wind_direction_10m || 65}°`;
                const rain = cur.precipitation || cur.rain || 0;
                STATE.telemetry.rainfall = Math.round(rain * 10) / 10;
                STATE.telemetry.weatherCode = cur.weather_code || 0;
                STATE.telemetry.weatherCondition = getWeatherInfo(cur.weather_code).text;
                STATE.telemetry.lastUpdated = new Date().toLocaleTimeString("en-IN") + " IST";
                STATE.dataStatus = "LIVE";

                if (daily && daily.sunrise && daily.sunrise[0]) {
                    STATE.telemetry.sunrise = new Date(daily.sunrise[0]).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    STATE.telemetry.sunset = new Date(daily.sunset[0]).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }

                // Compute real-life atmospheric risk metrics
                const rainNow = cur.precipitation || cur.rain || 0;
                const todayRainSum = (daily && daily.precipitation_sum && daily.precipitation_sum[0]) ? daily.precipitation_sum[0] : 0;
                const maxWind = (daily && daily.wind_speed_10m_max && daily.wind_speed_10m_max[0]) ? daily.wind_speed_10m_max[0] : (cur.wind_speed_10m || 10);
                const wCode = cur.weather_code || 0;

                let riskScore = 15;
                let riskLevel = "NORMAL";
                let leadTime = 12.0;
                let waterLevel = 0.4;
                let heroTitle = "Atmospheric Baseline Stable";
                let heroDesc = `Current conditions: ${getWeatherInfo(wCode).text} at ${cur.temperature_2m}°C. Safe for outdoor routines.`;
                let heroColor = "emerald";

                if (rainNow >= 20 || todayRainSum >= 50 || wCode === 82 || wCode === 96 || wCode === 99) {
                    riskScore = 88;
                    riskLevel = "CRITICAL";
                    leadTime = 2.5;
                    waterLevel = 2.8;
                    heroTitle = "CRITICAL: Severe Cloudburst & Inundation Warning";
                    heroDesc = `Severe precipitation observed (${rainNow} mm/h, ${todayRainSum}mm today). High risk of flash flooding. Move to high ground immediately.`;
                    heroColor = "red";
                } else if (rainNow >= 8 || todayRainSum >= 25 || wCode === 95 || wCode === 65 || maxWind >= 45) {
                    riskScore = 68;
                    riskLevel = "HIGH";
                    leadTime = 4.5;
                    waterLevel = 1.6;
                    heroTitle = "HIGH RISK: Intense Rain & Thunderstorm Nowcast";
                    heroDesc = `Localized heavy downpours (${rainNow} mm/h) and wind gusts (${maxWind} km/h). Waterlogging expected in lowlands.`;
                    heroColor = "amber";
                } else if (rainNow >= 2 || todayRainSum >= 8 || wCode === 53 || wCode === 55 || wCode === 63 || wCode === 81) {
                    riskScore = 42;
                    riskLevel = "MODERATE";
                    leadTime = 8.0;
                    waterLevel = 0.9;
                    heroTitle = "MODERATE: Monsoon Rain & Inundation Watch";
                    heroDesc = `Moderate showers underway (${rainNow} mm/h). Roads may experience transient water accumulation.`;
                    heroColor = "blue";
                } else if (cur.temperature_2m >= 38) {
                    riskScore = 60;
                    riskLevel = "CAUTION";
                    leadTime = 6.0;
                    waterLevel = 0.2;
                    heroTitle = "HEATWAVE: High Temperature Alert";
                    heroDesc = `Ground temperature recorded at ${cur.temperature_2m}°C. Stay hydrated and avoid outdoor exposure during peak afternoon hours.`;
                    heroColor = "orange";
                }

                STATE.telemetry.riskScore = riskScore;
                STATE.telemetry.riskLevel = riskLevel;
                STATE.telemetry.leadTimeHours = leadTime;
                STATE.telemetry.waterLevel = waterLevel;
                STATE.telemetry.heroTitle = heroTitle;
                STATE.telemetry.heroDesc = heroDesc;
                STATE.telemetry.heroColor = heroColor;

                // 24h Hourly Forecast
                if (hourly && hourly.time) {
                    const currentHour = new Date().getHours();
                    const next24 = [];
                    for (let i = 0; i < 24; i++) {
                        const idx = currentHour + i;
                        if (idx < hourly.time.length) {
                            const timeStr = new Date(hourly.time[idx]).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                            const t = Math.round(hourly.temperature_2m[idx]);
                            const prob = hourly.precipitation_probability[idx] || 0;
                            const rainAmount = hourly.precipitation[idx] || 0;
                            const hourlyWCode = hourly.weather_code[idx] || 0;
                            const wInfo = getWeatherInfo(hourlyWCode);
                            const wind = Math.round(hourly.wind_speed_10m[idx] || 0);

                            let risk = "Normal";
                            if (prob >= 70 || rainAmount >= 15 || hourlyWCode >= 95) risk = "Critical";
                            else if (prob >= 40 || rainAmount >= 5) risk = "Moderate";

                            next24.push({
                                time: i === 0 ? "Now" : timeStr,
                                temp: t,
                                rainProb: prob,
                                rainMm: rainAmount,
                                weatherCode: hourlyWCode,
                                weatherIcon: wInfo.icon,
                                weatherText: wInfo.text,
                                wind: wind,
                                risk: risk
                            });
                        }
                    }
                    STATE.hourlyForecast = next24;
                }

                // 7-Day Forecast
                if (daily && daily.time) {
                    const days = [];
                    for (let i = 0; i < Math.min(daily.time.length, 7); i++) {
                        const dateObj = new Date(daily.time[i]);
                        const dayName = i === 0 ? "Today" : (i === 1 ? "Tomorrow" : dateObj.toLocaleDateString('en-US', { weekday: 'short' }));
                        const dateFormatted = dateObj.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
                        const maxT = Math.round(daily.temperature_2m_max[i]);
                        const minT = Math.round(daily.temperature_2m_min[i]);
                        const dailyWCode = daily.weather_code[i] || 0;
                        const wInfo = getWeatherInfo(dailyWCode);
                        const rainProb = daily.precipitation_probability_max ? daily.precipitation_probability_max[i] : 40;
                        const rainSum = daily.precipitation_sum ? Math.round(daily.precipitation_sum[i] * 10) / 10 : 0;
                        const windMax = daily.wind_speed_10m_max ? Math.round(daily.wind_speed_10m_max[i]) : 15;

                        let riskLevel = "Normal";
                        let precaution = "No special precautions required.";
                        if (rainSum >= 50 || dailyWCode >= 95) {
                            riskLevel = "Critical";
                            precaution = "Flash flood & severe storm alert. Avoid non-essential travel.";
                        } else if (rainSum >= 15 || rainProb >= 60 || windMax >= 35) {
                            riskLevel = "Caution";
                            precaution = "Carry rain gear, stay clear of low-lying waterlogged roads.";
                        } else if (rainSum >= 5 || rainProb >= 30) {
                            riskLevel = "Advisory";
                            precaution = "Light intermittent showers expected. Keep umbrella handy.";
                        }

                        days.push({
                            index: i,
                            dayName,
                            dateFormatted,
                            maxTemp: maxT,
                            minTemp: minT,
                            weatherCode: dailyWCode,
                            weatherText: wInfo.text,
                            weatherIcon: wInfo.icon,
                            rainProb,
                            rainSum,
                            windMax,
                            riskLevel,
                            precaution
                        });
                    }
                    STATE.dailyForecast = days;
                }

                // Update dynamic localized relief shelters & alerts for this exact location
                updateLocalShelters(lat, lng, STATE.currentLocationName);
                updateLocalizedAlerts(STATE.telemetry, STATE.dailyForecast, STATE.currentLocationName);

                STATE.precautions = generatePrecautions(STATE.telemetry, STATE.dailyForecast, STATE.alerts);
                cacheWeatherData();
                if (!silent) showToast(`🌤️ Live Data Loaded for ${STATE.currentLocationName.split(',')[0]}`, "success");
            }
        }
    } catch(err) {
        console.warn("Using cached telemetry:", err.message);
        STATE.dataStatus = "CACHED";
        loadCachedWeather();
        if (!silent) showToast("⚠️ Network issue: Serving cached forecast.", "info");
    }

    if (STATE.currentTab === "home") {
        const viewport = document.getElementById("screen-viewport");
        if (viewport) viewport.innerHTML = renderHomeScreen();
        lucide.createIcons();
    } else if (STATE.currentTab === "map" && STATE.activeMap) {
        initMobileMap();
    } else if (STATE.currentTab === "evacuate" && STATE.evacMap) {
        initEvacuateRouteMap();
    } else if (STATE.currentTab === "shelters" || STATE.currentTab === "alerts") {
        navigate(STATE.currentTab);
    }
}

function generatePrecautions(telemetry, daily, alerts) {
    const list = [];
    const t = telemetry;
    const curCode = t.weatherCode;

    if (t.rainfall >= 25 || (daily[0] && daily[0].rainSum >= 30)) {
        list.push({
            id: "PREC-01",
            category: "Emergency",
            badgeColor: "bg-red-100 text-red-800 border-red-300",
            icon: "waves",
            title: "Flash Flood & Inundation Hazard",
            reason: `Intense localized precipitation observed (${t.rainfall} mm/h). High runoff expected.`,
            action: "Avoid travelling near rivers, underpasses, and low-lying areas. Move essential belongings upstairs.",
            timePeriod: "Next 3 to 6 Hours"
        });
    } else if (t.rainfall >= 5 || (daily[0] && daily[0].rainProb >= 50)) {
        list.push({
            id: "PREC-02",
            category: "Advisory",
            badgeColor: "bg-blue-100 text-blue-800 border-blue-300",
            icon: "umbrella",
            title: "Rain Gear & Commute Alert",
            reason: "Persistent rain showers forecasted across the urban sector.",
            action: "Carry an umbrella and expect minor delays near waterlogged road junctions.",
            timePeriod: "Throughout Today"
        });
    }

    if (curCode === 95 || curCode === 96 || curCode === 99) {
        list.push({
            id: "PREC-03",
            category: "Caution",
            badgeColor: "bg-purple-100 text-purple-800 border-purple-300",
            icon: "zap",
            title: "Severe Lightning & Thunderstorm Activity",
            reason: "Atmospheric instability producing convective lightning strikes.",
            action: "Stay indoors during active thunder. Avoid open fields, metal fencing, and tall isolated trees.",
            timePeriod: "Next 2 Hours"
        });
    }

    if (t.windSpeed >= 35) {
        list.push({
            id: "PREC-04",
            category: "Caution",
            badgeColor: "bg-amber-100 text-amber-800 border-amber-300",
            icon: "wind",
            title: "Strong Surface Wind Gusts",
            reason: `Wind speeds clocked at ${t.windSpeed} km/h with localized cross-gusts.`,
            action: "Secure loose rooftop objects, tin sheds, and stay clear of weak tree branches or hoardings.",
            timePeriod: "Active Now"
        });
    }

    list.push({
        id: "PREC-06",
        category: "Normal",
        badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-300",
        icon: "battery-charging",
        title: "Communication & Power Backup",
        reason: "Precautionary power grid maintenance during severe weather seasons.",
        action: "Keep your mobile phone and powerbanks charged to utilize zero-signal BLE mesh SOS if grid trips.",
        timePeriod: "All Day"
    });

    return list;
}

function cacheWeatherData() {
    try {
        const payload = {
            telemetry: STATE.telemetry,
            hourlyForecast: STATE.hourlyForecast,
            dailyForecast: STATE.dailyForecast,
            precautions: STATE.precautions,
            currentLocationName: STATE.currentLocationName,
            userCoords: STATE.userCoords,
            timestamp: Date.now()
        };
        localStorage.setItem("rakshacast_weather_cache", JSON.stringify(payload));
    } catch(e) {}
}

function loadCachedWeather() {
    try {
        const cached = localStorage.getItem("rakshacast_weather_cache");
        if (cached) {
            const data = JSON.parse(cached);
            STATE.telemetry = { ...STATE.telemetry, ...data.telemetry, lastUpdated: data.telemetry.lastUpdated + " (Cached)" };
            STATE.hourlyForecast = data.hourlyForecast || [];
            STATE.dailyForecast = data.dailyForecast || [];
            STATE.precautions = data.precautions || [];
            STATE.dataStatus = "CACHED";
        }
    } catch(e) {}
}

function loadSettingsFromStorage() {
    try {
        const saved = localStorage.getItem("rakshacast_user_settings");
        if (saved) STATE.settings = { ...STATE.settings, ...JSON.parse(saved) };
        const hist = localStorage.getItem("rakshacast_alert_history");
        if (hist) STATE.alertDeliveryHistory = JSON.parse(hist);
    } catch(e) {}
}

function saveSettingsToStorage() {
    try {
        localStorage.setItem("rakshacast_user_settings", JSON.stringify(STATE.settings));
        localStorage.setItem("rakshacast_alert_history", JSON.stringify(STATE.alertDeliveryHistory));
    } catch(e) {}
}

// =============================================================
// CITIZEN SOS / EVACUATE DISPATCH -> ROUTED TO ADMIN / NDRF ONLY
// =============================================================
function submitSOSDistress() {
    const name = document.getElementById("sos-name").value || STATE.citizenProfile.name;
    const type = document.getElementById("sos-type").value;
    const msg = document.getElementById("sos-msg").value || "Trapped citizen requesting extraction.";

    const newSOS = {
        id: `SOS-${Math.floor(1000 + Math.random() * 8999)}`,
        userName: name,
        phone: STATE.citizenProfile.phone,
        emergencyType: type,
        peopleCount: 4,
        location: STATE.currentLocationName,
        lat: STATE.userCoords[0],
        lng: STATE.userCoords[1],
        hasInfant: true,
        hasElderly: true,
        hasMedical: true,
        message: msg,
        triageScore: 99.0,
        status: "SUBMITTED",
        assignedTeam: "Pending NDRF Dispatch",
        time: "Just now"
    };

    STATE.sosQueue.unshift(newSOS);

    // If currently in Citizen mode, give citizen confirmation (NOT alarm self-alert)
    if (!STATE.isAuthority) {
        showCitizenConfirmationModal(newSOS);
    } else {
        // If in Admin mode, trigger Admin dispatch sound & alert
        triggerAdminIncidentNotification(newSOS);
    }
}

function requestEvacuationExtraction() {
    const newSOS = {
        id: `EVAC-${Math.floor(1000 + Math.random() * 8999)}`,
        userName: STATE.citizenProfile.name,
        phone: STATE.citizenProfile.phone,
        emergencyType: "Evacuation Assistance (Cutoff Route)",
        peopleCount: STATE.citizenProfile.familyMembersCount,
        location: STATE.currentLocationName,
        lat: STATE.userCoords[0],
        lng: STATE.userCoords[1],
        hasInfant: false,
        hasElderly: true,
        hasMedical: false,
        message: "Evacuation path waterlogged. Requesting NDRF amphibian / boat transport.",
        triageScore: 88.0,
        status: "SUBMITTED",
        assignedTeam: "Pending Assignment",
        time: "Just now"
    };

    STATE.sosQueue.unshift(newSOS);

    if (!STATE.isAuthority) {
        showCitizenConfirmationModal(newSOS);
    } else {
        triggerAdminIncidentNotification(newSOS);
    }
}

function showCitizenConfirmationModal(sosRecord) {
    const container = document.getElementById("modal-container");
    if (!container) return;

    container.innerHTML = `
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl border-2 border-emerald-500 animate-bounce duration-500">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-black text-xl">
                    ✓
                </div>
                <div>
                    <h3 class="text-sm font-extrabold text-slate-900">Distress Dispatched to NDRF</h3>
                    <p class="text-[10px] text-slate-500 font-mono">Incident ID: ${sosRecord.id}</p>
                </div>
            </div>

            <div class="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs space-y-1.5 text-emerald-950">
                <p class="font-bold">🚨 NDRF Command Room Alerted!</p>
                <p class="text-[11px] leading-relaxed">
                    Your GPS coordinates and family triage parameters have been transmitted to the <b>10th NDRF Battalion Command Room</b>. A rescue team is being assigned.
                </p>
                <div class="pt-1 text-[10px] font-mono text-emerald-800 flex justify-between">
                    <span>Status: <b>SUBMITTED (IN QUEUE)</b></span>
                    <span>Triage: <b>${sosRecord.triageScore}/100</b></span>
                </div>
            </div>

            <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[10px] text-slate-600">
                💡 <b>Citizen Instruction:</b> Stay on high elevation. Keep your phone charged. An automated IVR status update will ring your phone once the rescue boat departs.
            </div>

            <button onclick="closeModal()" class="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white rounded-xl text-xs font-bold shadow">
                Acknowledge & Monitor Queue
            </button>
        </div>
    `;
    container.classList.remove("hidden");
    container.classList.add("flex");
    lucide.createIcons();
}

function triggerAdminIncidentNotification(sosRecord) {
    playSirenPulse();
    showToast(`🚨 NEW CITIZEN DISTRESS: ${sosRecord.userName} at ${sosRecord.location}!`, "critical");
    
    // In-app alert for Admin
    const container = document.getElementById("modal-container");
    if (!container) return;

    container.innerHTML = `
        <div class="bg-white border-2 border-red-600 rounded-2xl max-w-sm w-full p-5 space-y-3.5 shadow-2xl animate-pulse">
            <div class="flex items-center justify-between">
                <span class="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-red-100 text-red-800 border border-red-300">
                    🚨 INCOMING CITIZEN SOS
                </span>
                <span class="text-[10px] font-mono text-slate-500 font-bold">${sosRecord.id}</span>
            </div>
            <div>
                <h3 class="text-sm font-extrabold text-slate-900">${sosRecord.userName} (${sosRecord.peopleCount} Persons)</h3>
                <p class="text-xs text-slate-700 mt-1 font-medium">📍 ${sosRecord.location} • Lat ${sosRecord.lat.toFixed(3)}, Lon ${sosRecord.lng.toFixed(3)}</p>
                <p class="text-xs text-red-700 font-bold mt-1">“${sosRecord.message}”</p>
            </div>
            <div class="flex space-x-2 pt-1">
                <button onclick="assignRescueTeam('${sosRecord.id}'); closeModal();" class="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow">
                    Dispatch Motor Boat #4
                </button>
                <button onclick="closeModal()" class="flex-1 py-2 bg-slate-200 text-slate-800 rounded-xl text-xs font-bold hover:bg-slate-300">
                    Review in Table
                </button>
            </div>
        </div>
    `;
    container.classList.remove("hidden");
    container.classList.add("flex");
    lucide.createIcons();
}

function assignRescueTeam(sosId) {
    const target = STATE.sosQueue.find(s => s.id === sosId);
    if (target) {
        target.status = "TEAM_EN_ROUTE";
        target.assignedTeam = "NDRF Bravo Alpha (Motor Boat #4)";
        showToast(`🚨 Assigned NDRF Motor Boat #4 to ${target.userName}!`, "success");
        if (STATE.currentTab === "authority") {
            const viewport = document.getElementById("screen-viewport");
            if (viewport) viewport.innerHTML = renderAuthorityScreen();
            lucide.createIcons();
        }
    }
}

// =============================================================
// ROLE TOGGLE (CITIZEN VS NDRF ADMIN)
// =============================================================
function toggleAuthorityMode() {
    STATE.isAuthority = !STATE.isAuthority;
    const btn = document.getElementById("role-toggle-btn");
    
    if (STATE.isAuthority) {
        if (btn) btn.innerText = "🚨 NDRF Officer View";
        btn.className = "px-2.5 py-1 rounded-lg text-[10px] font-bold bg-red-800 text-red-100 hover:bg-red-700 transition border border-red-600";
        showToast("👮 Switched to NDRF Incident Commander View", "info");
        navigate("authority");
    } else {
        if (btn) btn.innerText = "👤 Citizen View";
        btn.className = "px-2.5 py-1 rounded-lg text-[10px] font-bold bg-blue-800 text-blue-100 hover:bg-blue-700 transition border border-blue-600";
        showToast("👤 Switched to Citizen View", "info");
        navigate("home");
    }
}

// =============================================================
// NAVIGATION & VIEWS
// =============================================================
function navigate(tabId) {
    STATE.currentTab = tabId;
    const viewport = document.getElementById("screen-viewport");
    if (!viewport) return;

    viewport.scrollTop = 0;
    updateBottomNav();

    switch(tabId) {
        case "home": viewport.innerHTML = renderHomeScreen(); break;
        case "map": viewport.innerHTML = renderLiveMapScreen(); initMobileMap(); break;
        case "evacuate": viewport.innerHTML = renderEvacuateScreen(); initEvacuateRouteMap(); break;
        case "alerts": viewport.innerHTML = renderAlertsScreen(); break;
        case "profile": viewport.innerHTML = renderProfileScreen(); break;
        case "sos": viewport.innerHTML = renderSOSScreen(); break;
        case "shelters": viewport.innerHTML = renderSheltersScreen(); break;
        case "mesh-simulator": viewport.innerHTML = renderMeshSimulatorScreen(); break;
        case "cwc-telemetry": viewport.innerHTML = renderCwcTelemetryScreen(); break;
        case "broadcast-preview": viewport.innerHTML = renderBroadcastPreviewScreen(); break;
        case "recovery": viewport.innerHTML = renderRecoveryScreen(); break;
        case "family-safety": viewport.innerHTML = renderFamilySafetyScreen(); break;
        case "evac-kit": viewport.innerHTML = renderEvacKitScreen(); break;
        case "authority": viewport.innerHTML = renderAuthorityScreen(); break;
        default: viewport.innerHTML = renderHomeScreen();
    }

    lucide.createIcons();
}

function updateBottomNav() {
    const nav = document.getElementById("bottom-tab-bar");
    if (!nav) return;

    const tabs = [
        { id: "home", label: "Nowcast", icon: "cloud-lightning" },
        { id: "map", label: "Live Map", icon: "map" },
        { id: "evacuate", label: "Evacuate", icon: "navigation" },
        { id: "alerts", label: "Alerts", icon: "bell" },
        { id: "profile", label: STATE.isAuthority ? "Officer Profile" : "Citizen Profile", icon: STATE.isAuthority ? "shield" : "user" }
    ];

    nav.innerHTML = tabs.map(t => {
        const isActive = STATE.currentTab === t.id;
        return `
            <button onclick="navigate('${t.id}')" class="flex flex-col items-center justify-center py-1 flex-1 ${isActive ? 'text-blue-900 font-extrabold' : 'text-slate-500 font-medium'} transition active:scale-90">
                <i data-lucide="${t.icon}" class="w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}"></i>
                <span class="text-[9px] mt-0.5">${t.label}</span>
            </button>
        `;
    }).join("");
}

// -------------------------------------------------------------
// 1. HOME SCREEN
// -------------------------------------------------------------
function renderHomeScreen() {
    const t = STATE.telemetry;

    return `
        <div class="space-y-3.5">
            
            <!-- SECTION 1: SEARCH & GPS LOCATION BAR -->
            <div class="bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs space-y-2">
                <div class="flex items-center space-x-1.5">
                    <i data-lucide="map-pin" class="w-4 h-4 text-orange-600 shrink-0"></i>
                    <input id="loc-search-input" type="text" placeholder="Search Indian City / District..." class="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-900" onkeydown="if(event.key==='Enter') handleLocationSearch(this.value)">
                    <button onclick="handleLocationSearch(document.getElementById('loc-search-input').value)" class="px-2.5 py-1 bg-blue-900 text-white font-bold rounded-lg text-xs shrink-0">
                        Search
                    </button>
                    <button onclick="detectDeviceGPS()" title="Use GPS" class="p-1 bg-slate-100 border border-slate-300 text-blue-900 hover:bg-slate-200 rounded-lg shrink-0">
                        <i data-lucide="crosshair" class="w-4 h-4"></i>
                    </button>
                    <button onclick="fetchLiveOpenMeteo(STATE.userCoords[0], STATE.userCoords[1])" title="Refresh Live Data" class="p-1 bg-slate-100 border border-slate-300 text-blue-900 hover:bg-slate-200 rounded-lg shrink-0">
                        <i data-lucide="rotate-cw" class="w-4 h-4"></i>
                    </button>
                </div>
                <div class="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                    <span class="truncate">📍 Current: <b>${STATE.currentLocationName}</b></span>
                    <span class="px-1.5 py-0.2 rounded font-bold text-[9px] ${STATE.dataStatus === 'LIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                        ● ${STATE.dataStatus} FEED
                    </span>
                </div>
            </div>

            <!-- OFFLINE WARNING BANNER -->
            ${STATE.isOffline ? `
                <div class="bg-amber-50 border-l-4 border-amber-500 p-2.5 rounded-xl flex items-center justify-between text-xs text-amber-900">
                    <div class="flex items-center space-x-2">
                        <i data-lucide="wifi-off" class="w-4 h-4 text-amber-700"></i>
                        <span><b>Offline Mode:</b> Serving cached forecast from ${t.lastUpdated}</span>
                    </div>
                </div>
            ` : ''}

            <!-- SECTION 2: CURRENT RISK HERO CARD -->
            <div class="bg-white border-l-4 ${t.riskLevel === 'CRITICAL' ? 'border-red-600' : (t.riskLevel === 'HIGH' ? 'border-amber-600' : (t.riskLevel === 'MODERATE' ? 'border-blue-600' : (t.riskLevel === 'CAUTION' ? 'border-orange-500' : 'border-emerald-600')))} rounded-xl p-4 shadow-sm border border-slate-200 space-y-3">
                <div class="flex items-center justify-between">
                    <span class="px-2.5 py-0.5 rounded text-[10px] font-black tracking-wide uppercase ${t.riskLevel === 'CRITICAL' ? 'bg-red-100 text-red-800 border-red-300' : (t.riskLevel === 'HIGH' ? 'bg-amber-100 text-amber-800 border-amber-300' : (t.riskLevel === 'MODERATE' ? 'bg-blue-100 text-blue-800 border-blue-300' : (t.riskLevel === 'CAUTION' ? 'bg-orange-100 text-orange-800 border-orange-300' : 'bg-emerald-100 text-emerald-800 border-emerald-300')))} border">
                        ${t.riskLevel} ATMOSPHERIC RISK (${t.riskScore}/100)
                    </span>
                    <span class="text-[11px] text-slate-600 font-bold">Action Window: <b class="${t.riskLevel === 'CRITICAL' ? 'text-red-600' : 'text-slate-900'} font-black">${t.leadTimeHours} hrs</b></span>
                </div>

                <div>
                    <h2 class="text-base font-extrabold text-slate-900 leading-snug">${t.heroTitle || "Severe Weather Nowcast"}</h2>
                    <p class="text-xs text-slate-700 leading-relaxed mt-1">${t.heroDesc || `Rain intensity: ${t.rainfall} mm/h. Weather condition: ${t.weatherCondition}.`}</p>
                </div>

                <div class="flex items-center space-x-2 pt-1">
                    <button onclick="navigate('evacuate')" class="flex-1 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow flex items-center justify-center space-x-1.5 transition active:scale-95">
                        <i data-lucide="navigation" class="w-4 h-4"></i>
                        <span>Evacuate Safe Route</span>
                    </button>
                    <button onclick="navigate('sos')" class="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow flex items-center justify-center space-x-1.5 transition active:scale-95 ${t.riskLevel === 'CRITICAL' ? 'animate-pulse' : ''}">
                        <i data-lucide="radio" class="w-4 h-4"></i>
                        <span>Send SOS Distress</span>
                    </button>
                </div>
            </div>

            <!-- SECTION 3: TODAY'S WEATHER (METEOROLOGICAL TELEMETRY) -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100">
                    <div class="flex items-center space-x-2">
                        <i data-lucide="sun" class="w-4 h-4 text-amber-500"></i>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Today's Weather</h3>
                    </div>
                    <span class="text-[9px] font-mono text-slate-500">Updated: ${t.lastUpdated}</span>
                </div>

                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-3xl font-black text-slate-900 font-mono">${t.temperature}°<span class="text-base font-normal text-slate-500">C</span></div>
                        <p class="text-[11px] text-slate-500 font-medium">Feels like <b>${t.feelsLike}°C</b> • ${t.weatherCondition}</p>
                    </div>
                    <div class="text-right">
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-50 text-blue-900 border border-blue-200">
                            🌧️ ${STATE.hourlyForecast[0] ? STATE.hourlyForecast[0].rainProb : 65}% Rain Prob
                        </span>
                        <div class="text-[10px] text-slate-500 mt-1">Sunrise ${t.sunrise} • Sunset ${t.sunset}</div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-2 text-center text-xs">
                    <div class="p-2 bg-slate-50 rounded-xl border border-slate-200">
                        <span class="text-[9px] text-slate-500 font-bold uppercase block">Rain Intensity</span>
                        <span class="text-xs font-black text-blue-900 mt-0.5 font-mono">${t.rainfall} mm/h</span>
                    </div>
                    <div class="p-2 bg-slate-50 rounded-xl border border-slate-200">
                        <span class="text-[9px] text-slate-500 font-bold uppercase block">Humidity</span>
                        <span class="text-xs font-black text-slate-900 mt-0.5 font-mono">${t.humidity}%</span>
                    </div>
                    <div class="p-2 bg-slate-50 rounded-xl border border-slate-200">
                        <span class="text-[9px] text-slate-500 font-bold uppercase block">Wind & Direction</span>
                        <span class="text-xs font-black text-slate-900 mt-0.5 font-mono">${t.windSpeed} km/h</span>
                    </div>
                </div>

                <div class="text-[9px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100">
                    <span>Source: <b>${STATE.dataSource}</b></span>
                    <span class="font-bold text-blue-900">GPS Live Ground Node</span>
                </div>
            </div>

            <!-- SECTION 4: TODAY'S HOURLY FORECAST -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-2.5">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-1.5">
                        <i data-lucide="clock" class="w-4 h-4 text-blue-900"></i>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Today's Hourly Nowcast</h3>
                    </div>
                    <button onclick="showHourlyForecastModal()" class="text-[10px] text-blue-900 font-bold hover:underline">
                        View Full 24h Table →
                    </button>
                </div>

                <div class="flex space-x-2 overflow-x-auto pb-1.5 custom-scrollbar">
                    ${STATE.hourlyForecast.map((h, i) => `
                        <div class="min-w-[72px] p-2 rounded-xl text-center flex flex-col items-center justify-between ${i === 0 ? 'bg-blue-900 text-white shadow' : 'bg-slate-50 border border-slate-200 text-slate-800'}">
                            <span class="text-[10px] font-bold ${i === 0 ? 'text-blue-200' : 'text-slate-500'} font-mono">${h.time}</span>
                            <i data-lucide="${h.weatherIcon}" class="w-4 h-4 my-1.5 ${i === 0 ? 'text-amber-400' : 'text-blue-900'}"></i>
                            <span class="text-xs font-black font-mono">${h.temp}°</span>
                            <span class="text-[9px] font-bold mt-1 ${i === 0 ? 'text-blue-200' : (h.rainProb > 50 ? 'text-blue-600' : 'text-slate-400')} font-mono">
                                ${h.rainProb}%
                            </span>
                            <span class="text-[8px] px-1 py-0.2 rounded mt-1 font-bold ${h.risk === 'Critical' ? 'bg-red-500 text-white' : (h.risk === 'Moderate' ? 'bg-amber-400 text-slate-900' : 'bg-emerald-600 text-white')}">
                                ${h.risk}
                            </span>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- SECTION 5: TODAY'S PRECAUTIONS -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                <div class="flex items-center justify-between pb-1.5 border-b border-slate-100">
                    <div class="flex items-center space-x-2">
                        <i data-lucide="shield-alert" class="w-4 h-4 text-emerald-700"></i>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Today's Precaution Engine</h3>
                    </div>
                    <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                        AI Recommended
                    </span>
                </div>

                <div class="space-y-2">
                    ${STATE.precautions.map(p => `
                        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                            <div class="flex items-center justify-between">
                                <span class="text-[9px] px-2 py-0.2 rounded font-black uppercase border ${p.badgeColor}">
                                    ${p.category}
                                </span>
                                <span class="text-[9px] text-slate-500 font-mono">🕒 ${p.timePeriod}</span>
                            </div>
                            <h4 class="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
                                <i data-lucide="${p.icon}" class="w-3.5 h-3.5 text-blue-900"></i>
                                <span>${p.title}</span>
                            </h4>
                            <p class="text-[11px] text-slate-600"><b>Why:</b> ${p.reason}</p>
                            <p class="text-[11px] text-slate-900 font-medium bg-white p-2 rounded-lg border border-slate-200">
                                <b>Action:</b> ${p.action}
                            </p>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- SECTION 6: UPCOMING 7-DAY FORECAST -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-2.5">
                <div class="flex items-center justify-between pb-1.5 border-b border-slate-100">
                    <div class="flex items-center space-x-1.5">
                        <i data-lucide="calendar" class="w-4 h-4 text-blue-900"></i>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Next 7 Days Forecast</h3>
                    </div>
                    <span class="text-[9px] text-slate-400">Tap day for details</span>
                </div>

                <div class="space-y-1.5">
                    ${STATE.dailyForecast.map(d => `
                        <div onclick="showDayDetailModal(${d.index})" class="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer transition active:scale-98">
                            <div class="w-20">
                                <div class="text-xs font-extrabold text-slate-900">${d.dayName}</div>
                                <div class="text-[9px] text-slate-400">${d.dateFormatted}</div>
                            </div>
                            <div class="flex items-center space-x-2 flex-1 justify-center">
                                <i data-lucide="${d.weatherIcon}" class="w-4 h-4 text-blue-900"></i>
                                <span class="text-xs text-slate-700 font-medium truncate max-w-[100px]">${d.weatherText}</span>
                            </div>
                            <div class="text-right w-24">
                                <span class="text-xs font-black text-slate-900 font-mono">${d.maxTemp}° / ${d.minTemp}°</span>
                                <div class="text-[9px] font-bold ${d.riskLevel === 'Critical' ? 'text-red-600' : (d.riskLevel === 'Caution' ? 'text-orange-600' : 'text-blue-700')}">
                                    ${d.rainProb}% Rain (${d.riskLevel})
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- SECTION 7: ACTIVE OFFICIAL ALERTS -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-2.5">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-1.5">
                        <i data-lucide="bell" class="w-4 h-4 text-orange-600"></i>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Official Disaster Bulletins</h3>
                    </div>
                    <button onclick="navigate('alerts')" class="text-[10px] text-blue-900 font-bold hover:underline">View All →</button>
                </div>

                <div class="space-y-2">
                    ${STATE.alerts.map(a => `
                        <div class="p-3 bg-red-50 border border-red-200 rounded-xl space-y-1">
                            <div class="flex items-center justify-between">
                                <span class="text-[9px] font-bold text-red-800 bg-red-200/60 px-1.5 py-0.2 rounded font-mono">${a.severity}</span>
                                <span class="text-[9px] text-slate-500 font-mono">${a.timeIssued}</span>
                            </div>
                            <h4 class="text-xs font-bold text-slate-900">${a.title}</h4>
                            <p class="text-[10px] text-slate-700">${a.instructions}</p>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- SECTION 8: INNOVATION QUICK ACTIONS -->
            <div class="grid grid-cols-2 gap-2.5">
                <button onclick="navigate('mesh-simulator')" class="p-3 bg-white border border-slate-200 hover:border-blue-400 rounded-xl flex items-center space-x-2.5 text-left transition active:scale-95 shadow-xs">
                    <div class="w-9 h-9 rounded-lg bg-blue-100 text-blue-900 flex items-center justify-center shrink-0">
                        <i data-lucide="cpu" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-900">BLE Mesh Network</p>
                        <p class="text-[9px] text-slate-500">Zero-Signal Relay</p>
                    </div>
                </button>

                <button onclick="navigate('family-safety')" class="p-3 bg-white border border-slate-200 hover:border-emerald-400 rounded-xl flex items-center space-x-2.5 text-left transition active:scale-95 shadow-xs">
                    <div class="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-900 flex items-center justify-center shrink-0">
                        <i data-lucide="users" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-900">Family Safety</p>
                        <p class="text-[9px] text-slate-500">3 Members Safe</p>
                    </div>
                </button>

                <button onclick="navigate('cwc-telemetry')" class="p-3 bg-white border border-slate-200 hover:border-emerald-400 rounded-xl flex items-center space-x-2.5 text-left transition active:scale-95 shadow-xs">
                    <div class="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-900 flex items-center justify-center shrink-0">
                        <i data-lucide="waves" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-900">River Telemetry</p>
                        <p class="text-[9px] text-slate-500">CWC Water Sensors</p>
                    </div>
                </button>

                <button onclick="navigate('recovery')" class="p-3 bg-white border border-slate-200 hover:border-purple-400 rounded-xl flex items-center space-x-2.5 text-left transition active:scale-95 shadow-xs">
                    <div class="w-9 h-9 rounded-lg bg-purple-100 text-purple-900 flex items-center justify-center shrink-0">
                        <i data-lucide="qr-code" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-900">Relief Kit QR Auth</p>
                        <p class="text-[9px] text-slate-500">Anti-Hoarding</p>
                    </div>
                </button>
            </div>

            <!-- Hardware Search Beacon & Flashlight Strobe Controls -->
            <div class="bg-white border border-slate-200 rounded-xl p-3 space-y-2 shadow-xs">
                <p class="font-bold text-slate-800 text-[10px] uppercase">Emergency Hardware Tools (Darkness & Trap)</p>
                <div class="flex space-x-2">
                    <button id="acoustic-beacon-btn" onclick="toggleAcousticSearchBeacon()" class="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs border border-slate-300 flex items-center justify-center space-x-1.5 transition">
                        <i data-lucide="volume-2" class="w-4 h-4 text-red-600"></i>
                        <span>Acoustic Beacon (880Hz)</span>
                    </button>
                    <button id="strobe-btn" onclick="toggleFlashlightStrobe()" class="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs border border-slate-300 flex items-center justify-center space-x-1.5 transition">
                        <i data-lucide="zap" class="w-4 h-4 text-amber-600"></i>
                        <span>SOS Morse Strobe</span>
                    </button>
                </div>
            </div>

            <!-- Helpline Box -->
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-center justify-between">
                <div class="flex items-center space-x-2.5">
                    <div class="w-8 h-8 rounded-full bg-blue-900 text-white flex items-center justify-center shrink-0 font-bold text-xs">📞</div>
                    <div>
                        <p class="text-xs font-bold text-blue-950">National Disaster Helpline</p>
                        <p class="text-[10px] text-blue-800">NDRF: <b>1078</b> • Emergency: <b>112</b></p>
                    </div>
                </div>
                <a href="tel:1078" class="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-950 text-white rounded-lg text-xs font-bold transition">
                    Call 1078
                </a>
            </div>

        </div>
    `;
}

// -------------------------------------------------------------
// 2. LIVE MAP SCREEN (WITH MULTI-COLOR DANGER RADIUS CIRCLES & LEGEND)
// -------------------------------------------------------------
function renderLiveMapScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Geospatial Hazard Radius Map</h2>
                    <p class="text-[10px] text-slate-500">Color-coded impact zones with CWC River Sensors</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-red-100 text-red-800 font-bold">4 Danger Zones</span>
            </div>

            <!-- Color-Coded Hazard Radius Legend -->
            <div class="bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs text-[10px] space-y-1.5">
                <span class="font-bold text-slate-700 uppercase tracking-wider block text-[9px]">Map Hazard Radius Key:</span>
                <div class="grid grid-cols-2 gap-1.5">
                    <div class="flex items-center space-x-1.5">
                        <span class="w-3 h-3 rounded-full bg-blue-500 border border-blue-700 shrink-0"></span>
                        <span class="text-slate-800 font-medium"><b>Blue:</b> Flood Surge (1.2 km)</span>
                    </div>
                    <div class="flex items-center space-x-1.5">
                        <span class="w-3 h-3 rounded-full bg-red-500 border border-red-700 shrink-0"></span>
                        <span class="text-slate-800 font-medium"><b>Red:</b> Cyclone/Wind (1.5 km)</span>
                    </div>
                    <div class="flex items-center space-x-1.5">
                        <span class="w-3 h-3 rounded-full bg-purple-500 border border-purple-700 shrink-0"></span>
                        <span class="text-slate-800 font-medium"><b>Purple:</b> Lightning (800m)</span>
                    </div>
                    <div class="flex items-center space-x-1.5">
                        <span class="w-3 h-3 rounded-full bg-amber-500 border border-amber-700 shrink-0"></span>
                        <span class="text-slate-800 font-medium"><b>Amber:</b> Landslide (600m)</span>
                    </div>
                </div>
            </div>

            <!-- Inundation Forecast Time-Slider Deck -->
            <div class="bg-blue-950 text-white p-3 rounded-xl shadow space-y-2 border border-blue-900">
                <div class="flex items-center justify-between text-xs font-bold">
                    <span class="flex items-center space-x-1.5">
                        <i data-lucide="layers" class="w-4 h-4 text-orange-400"></i>
                        <span>Flood Inundation Surge: <b class="text-orange-400" id="inundation-label">+${STATE.inundationHour} Hours</b></span>
                    </span>
                    <span class="text-[10px] text-blue-200 font-mono">Surge Peak: 3.65m</span>
                </div>
                <div class="grid grid-cols-4 gap-1.5 pt-1">
                    <button onclick="setInundationTime(0)" class="py-1 rounded text-[10px] font-bold ${STATE.inundationHour === 0 ? 'bg-orange-500 text-white' : 'bg-blue-900 text-blue-200'}">Current</button>
                    <button onclick="setInundationTime(1)" class="py-1 rounded text-[10px] font-bold ${STATE.inundationHour === 1 ? 'bg-orange-500 text-white' : 'bg-blue-900 text-blue-200'}">+1 Hour</button>
                    <button onclick="setInundationTime(3)" class="py-1 rounded text-[10px] font-bold ${STATE.inundationHour === 3 ? 'bg-orange-500 text-white' : 'bg-blue-900 text-blue-200'}">+3 Hours</button>
                    <button onclick="setInundationTime(6)" class="py-1 rounded text-[10px] font-bold ${STATE.inundationHour === 6 ? 'bg-orange-500 text-white' : 'bg-blue-900 text-blue-200'}">+6 Hours</button>
                </div>
            </div>

            <!-- Leaflet Map Container -->
            <div class="w-full h-80 rounded-xl overflow-hidden border border-slate-300 shadow relative" id="mobile-map-div"></div>
        </div>
    `;
}

function initMobileMap() {
    setTimeout(() => {
        const container = document.getElementById("mobile-map-div");
        if (!container) return;
        
        if (STATE.activeMap) {
            STATE.activeMap.remove();
            STATE.activeMap = null;
        }

        const map = L.map('mobile-map-div', { zoomControl: false }).setView(STATE.userCoords, 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        L.control.zoom({ position: 'bottomright' }).addTo(map);

        // 1. BLUE RADIUS: Flood Inundation Danger Zone (1.2 km)
        L.circle(STATE.userCoords, {
            radius: 1200,
            color: "#2563eb",
            fillColor: "#3b82f6",
            fillOpacity: 0.22,
            weight: 2,
            dashArray: "6, 6"
        }).addTo(map).bindPopup("<b>🌊 Flood Inundation Hazard Radius (Blue)</b><br>Surge Radius: 1.2 km • Water Depth: +2.45m");

        // 2. RED RADIUS: Cyclone Wind & Heavy Impact Zone (1.5 km)
        L.circle([STATE.userCoords[0] - 0.009, STATE.userCoords[1] + 0.012], {
            radius: 1500,
            color: "#dc2626",
            fillColor: "#ef4444",
            fillOpacity: 0.18,
            weight: 2
        }).addTo(map).bindPopup("<b>🌪️ Cyclone & High Gust Hazard Radius (Red)</b><br>Wind Velocity: 42 km/h • Radius: 1.5 km");

        // 3. PURPLE RADIUS: Lightning & Thunderstorm Cell (800m)
        L.circle([STATE.userCoords[0] + 0.012, STATE.userCoords[1] - 0.010], {
            radius: 800,
            color: "#9333ea",
            fillColor: "#a855f7",
            fillOpacity: 0.22,
            weight: 2
        }).addTo(map).bindPopup("<b>⚡ Active Lightning Strike Hazard (Purple)</b><br>Convective Storm Cell Radius: 800m");

        // 4. AMBER RADIUS: Landslide & Slope Failure Risk (600m)
        L.circle([STATE.userCoords[0] + 0.008, STATE.userCoords[1] + 0.009], {
            radius: 600,
            color: "#d97706",
            fillColor: "#f59e0b",
            fillOpacity: 0.25,
            weight: 2
        }).addTo(map).bindPopup("<b>⚠️ Landslide / Rockfall Hazard (Amber)</b><br>Slope Failure Area: 600m");

        // User Marker
        L.circleMarker(STATE.userCoords, {
            radius: 9,
            fillColor: "#ea580c",
            color: "#ffffff",
            weight: 3,
            opacity: 1,
            fillOpacity: 0.9
        }).addTo(map).bindPopup("<b>📍 Your Current Location Node</b><br>Sector 4 Lowland Basin").openPopup();

        // Safe Shelters (Green)
        STATE.shelters.forEach(s => {
            L.circleMarker([s.lat, s.lng], {
                radius: 8,
                fillColor: "#15803d",
                color: "#ffffff",
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8
            }).addTo(map).bindPopup(`<b>🟢 ${s.name}</b><br>Safe Elevation: ${s.elevation}m<br>Capacity: ${s.available}/${s.capacity} beds available`);
        });

        STATE.activeMap = map;
    }, 150);
}

function setInundationTime(hours) {
    STATE.inundationHour = hours;
    const label = document.getElementById("inundation-label");
    if (label) label.innerText = hours === 0 ? "Current Baseline" : `+${hours} Hours`;
    showToast(`🌊 Updated Flood Inundation Model for +${hours} Hours`, "info");
}

// -------------------------------------------------------------
// 3. EVACUATE ROUTE SCREEN (WITH DANGER RADIUS OVERLAY)
// -------------------------------------------------------------
function renderEvacuateScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Evacuation Route Navigator</h2>
                    <p class="text-[10px] text-slate-500">Bypasses Blue Flood Zone along High Ridges</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-emerald-100 text-emerald-800 font-bold">Safe Route Locked</span>
            </div>

            <div class="w-full h-72 rounded-xl overflow-hidden border border-slate-300 shadow relative" id="evac-route-map"></div>

            <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 space-y-2">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-emerald-950">Destination: ${STATE.shelters[0] ? STATE.shelters[0].name : "Primary Safe Relief Camp"}</span>
                    <span class="text-[10px] font-bold text-emerald-800">${STATE.shelters[0] ? STATE.shelters[0].distance : "1.2 km"} (Safe Ridge Trail)</span>
                </div>
                <p class="text-[11px] text-emerald-900">Ascend via high-ground safe corridor (${STATE.shelters[0] ? STATE.shelters[0].elevation : 520}m MSL). Bypasses low-lying blue flood basin.</p>
                <div class="flex space-x-2 pt-1">
                    <button onclick="showToast('Turn-by-turn Voice Guidance started in Hindi/English.', 'success')" class="flex-1 py-2 bg-emerald-700 text-white rounded-lg text-xs font-bold shadow hover:bg-emerald-800">
                        Start Navigation
                    </button>
                    <button onclick="requestEvacuationExtraction()" class="flex-1 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold shadow active:scale-95 transition">
                        Request Rescue Pick
                    </button>
                </div>
            </div>
        </div>
    `;
}

function initEvacuateRouteMap() {
    setTimeout(() => {
        const container = document.getElementById("evac-route-map");
        if (!container) return;

        if (STATE.evacMap) {
            STATE.evacMap.remove();
            STATE.evacMap = null;
        }

        const map = L.map('evac-route-map', { zoomControl: false }).setView(STATE.userCoords, 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        const destShelter = STATE.shelters[0] || {
            name: "Primary High-Ridge Relief Center",
            lat: STATE.userCoords[0] + 0.0075,
            lng: STATE.userCoords[1] + 0.0085,
            elevation: 520,
            distance: "1.2 km"
        };

        // Blue Flood Zone (Avoid area)
        L.circle(STATE.userCoords, {
            radius: 800,
            color: "#2563eb",
            fillColor: "#3b82f6",
            fillOpacity: 0.18,
            weight: 2,
            dashArray: "4, 4"
        }).addTo(map).bindPopup(`<b>🌊 Blue Danger Radius: Flood Inundation Lowlands</b><br>Surge Water Depth: +${STATE.telemetry.waterLevel}m`);

        // Start Node
        L.circleMarker(STATE.userCoords, { radius: 8, fillColor: "#ea580c", color: "#fff", weight: 2, fillOpacity: 1 })
            .addTo(map).bindPopup(`<b>📍 Your Real Location</b><br>${STATE.currentLocationName}`);
            
        // Destination Shelter
        L.circleMarker([destShelter.lat, destShelter.lng], { radius: 8, fillColor: "#15803d", color: "#fff", weight: 2, fillOpacity: 1 })
            .addTo(map).bindPopup(`<b>🟢 ${destShelter.name}</b><br>Safe Elevation: ${destShelter.elevation}m MSL • Distance: ${destShelter.distance}`).openPopup();

        // Safe Route Polyline along elevated ridge
        const midLat1 = STATE.userCoords[0] + (destShelter.lat - STATE.userCoords[0]) * 0.35 + 0.0015;
        const midLng1 = STATE.userCoords[1] + (destShelter.lng - STATE.userCoords[1]) * 0.35 - 0.0010;
        const midLat2 = STATE.userCoords[0] + (destShelter.lat - STATE.userCoords[0]) * 0.70 + 0.0010;
        const midLng2 = STATE.userCoords[1] + (destShelter.lng - STATE.userCoords[1]) * 0.70 + 0.0008;

        const polyline = L.polyline([
            STATE.userCoords,
            [midLat1, midLng1],
            [midLat2, midLng2],
            [destShelter.lat, destShelter.lng]
        ], { color: '#15803d', weight: 5, dashArray: '5, 8' }).addTo(map);

        map.fitBounds(polyline.getBounds(), { padding: [30, 30] });
        STATE.evacMap = map;
    }, 150);
}

// -------------------------------------------------------------
// 4. DISTINCT CITIZEN PROFILE VS NDRF ADMIN PROFILE
// -------------------------------------------------------------
function renderProfileScreen() {
    if (STATE.isAuthority) {
        return renderAdminProfileView();
    } else {
        return renderCitizenProfileView();
    }
}

// Citizen Profile View
function renderCitizenProfileView() {
    const c = STATE.citizenProfile;
    const s = STATE.settings;

    return `
        <div class="space-y-3.5">
            
            <!-- Citizen Identity Badge -->
            <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-900 to-indigo-800 text-white flex items-center justify-center font-black text-lg shadow">
                        ${c.name.charAt(0)}
                    </div>
                    <div>
                        <div class="flex items-center space-x-1.5">
                            <h2 class="text-sm font-extrabold text-slate-900">${c.name}</h2>
                            <span class="px-1.5 py-0.2 rounded-full text-[9px] bg-emerald-100 text-emerald-800 font-bold">✓ Citizen Pass</span>
                        </div>
                        <p class="text-[10px] text-slate-500 font-mono">${c.phone} • ID: ${c.citizenId}</p>
                    </div>
                </div>
                <button onclick="openOtpVerificationModal()" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-blue-900 rounded-lg text-xs font-bold border border-slate-300">
                    Verify
                </button>
            </div>

            <!-- Citizen Details -->
            <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-2 text-xs">
                <span class="text-[10px] font-bold text-slate-500 uppercase block">Family Civil Defense Pass</span>
                <div class="grid grid-cols-2 gap-2 text-[11px]">
                    <div class="p-2 bg-slate-50 rounded-lg border border-slate-200">
                        <span class="text-[9px] text-slate-400 block">Blood Group</span>
                        <span class="font-bold text-red-700">${c.bloodGroup}</span>
                    </div>
                    <div class="p-2 bg-slate-50 rounded-lg border border-slate-200">
                        <span class="text-[9px] text-slate-400 block">Family Members</span>
                        <span class="font-bold text-slate-900">${c.familyMembersCount} Persons</span>
                    </div>
                </div>
            </div>

            <!-- Multi-Channel Alert Preferences -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100">
                    <div>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Citizen Alert Channels</h3>
                        <p class="text-[10px] text-slate-500">Where you receive weather sirens</p>
                    </div>
                    <button onclick="testMultiChannelAlertDispatch()" class="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold rounded-lg shadow active:scale-95 transition">
                        Test Channels
                    </button>
                </div>

                <div class="space-y-2.5 text-xs">
                    <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div class="flex items-center space-x-2">
                            <i data-lucide="smartphone" class="w-4 h-4 text-blue-900"></i>
                            <div>
                                <p class="font-bold text-slate-900">In-App Emergency Modal</p>
                                <p class="text-[9px] text-slate-500">Pop-up warning on high risk</p>
                            </div>
                        </div>
                        <input type="checkbox" ${s.inAppAlerts ? 'checked' : ''} onchange="toggleSetting('inAppAlerts', this.checked)" class="w-4 h-4 text-blue-900 rounded">
                    </div>

                    <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div class="flex items-center space-x-2">
                            <i data-lucide="bell" class="w-4 h-4 text-emerald-700"></i>
                            <div>
                                <p class="font-bold text-slate-900">Android Push (FCM)</p>
                                <p class="text-[9px] text-slate-500">Wake background notification</p>
                            </div>
                        </div>
                        <input type="checkbox" ${s.pushNotifications ? 'checked' : ''} onchange="toggleSetting('pushNotifications', this.checked)" class="w-4 h-4 text-blue-900 rounded">
                    </div>

                    <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div class="flex items-center space-x-2">
                            <i data-lucide="message-square" class="w-4 h-4 text-amber-700"></i>
                            <div>
                                <p class="font-bold text-slate-900">Cellular SMS Alert</p>
                                <p class="text-[9px] text-slate-500">Delivered to ${c.phone}</p>
                            </div>
                        </div>
                        <input type="checkbox" ${s.smsAlerts ? 'checked' : ''} onchange="toggleSetting('smsAlerts', this.checked)" class="w-4 h-4 text-blue-900 rounded">
                    </div>

                    <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div class="flex items-center space-x-2">
                            <i data-lucide="phone-call" class="w-4 h-4 text-red-700"></i>
                            <div>
                                <p class="font-bold text-slate-900">Automated IVR Siren Call</p>
                                <p class="text-[9px] text-slate-500">Emergency call for evacuation</p>
                            </div>
                        </div>
                        <input type="checkbox" ${s.phoneCallAlerts ? 'checked' : ''} onchange="toggleSetting('phoneCallAlerts', this.checked)" class="w-4 h-4 text-blue-900 rounded">
                    </div>
                </div>
            </div>

            <!-- Disclaimer -->
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center space-y-1">
                <p class="text-xs font-bold text-blue-950">Safety Service Notice</p>
                <p class="text-[10px] text-blue-900 leading-relaxed">
                    “RakshaCast alerts are an additional safety service and do not replace official emergency services.”
                </p>
            </div>

        </div>
    `;
}

// NDRF Admin Profile View
function renderAdminProfileView() {
    const a = STATE.adminProfile;

    return `
        <div class="space-y-3.5">
            
            <!-- Officer Identity Card -->
            <div class="bg-slate-900 text-white p-4 rounded-2xl border border-slate-700 shadow-sm flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center font-black text-xl shadow">
                        🎖️
                    </div>
                    <div>
                        <div class="flex items-center space-x-1.5">
                            <h2 class="text-sm font-extrabold text-white">${a.officerName}</h2>
                            <span class="px-1.5 py-0.2 rounded-full text-[9px] bg-red-500/30 text-red-300 font-bold border border-red-500/50">NDRF COMMAND</span>
                        </div>
                        <p class="text-[10px] text-slate-400 font-mono">${a.badgeNumber} • ${a.rank}</p>
                    </div>
                </div>
                <span class="px-2 py-1 bg-emerald-950 text-emerald-400 border border-emerald-700 rounded-lg text-[10px] font-black animate-pulse">
                    ${a.unitStatus}
                </span>
            </div>

            <!-- Command Unit Telemetry -->
            <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1 shadow-xs">
                    <span class="text-[10px] text-slate-500 font-bold uppercase">Battalion Unit</span>
                    <p class="text-xs font-extrabold text-slate-900">${a.battalion}</p>
                    <span class="text-[9px] text-blue-900 font-bold">Sector: ${a.dutySector}</span>
                </div>
                <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1 shadow-xs">
                    <span class="text-[10px] text-slate-500 font-bold uppercase">Active Assets</span>
                    <p class="text-xs font-extrabold text-slate-900">${a.boatsReady} Rescue Boats • ${a.dronesAirborne} Drones</p>
                    <span class="text-[9px] text-emerald-700 font-bold">Live GPS Tracking ON</span>
                </div>
            </div>

            <!-- Admin Incident Dispatch Control -->
            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100">
                    <div>
                        <h3 class="text-xs font-extrabold text-slate-900 uppercase tracking-wider">Live SOS Dispatch Queue</h3>
                        <p class="text-[10px] text-slate-500">Citizen distress calls in your sector</p>
                    </div>
                    <button onclick="navigate('authority')" class="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold rounded-lg shadow">
                        Open Control Room
                    </button>
                </div>

                <div class="space-y-2 text-xs">
                    ${STATE.sosQueue.map(s => `
                        <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-slate-900">${s.userName}</span>
                                <span class="text-[9px] font-bold ${s.status === 'TEAM_EN_ROUTE' ? 'text-emerald-700 bg-emerald-100 px-1.5 rounded' : 'text-red-700 bg-red-100 px-1.5 rounded'}">${s.status}</span>
                            </div>
                            <p class="text-[11px] text-slate-600">📍 ${s.location} (${s.peopleCount} Persons)</p>
                        </div>
                    `).join('')}
                </div>
            </div>

        </div>
    `;
}

// -------------------------------------------------------------
// 5. SOS DISTRESS SCREEN (CITIZEN INTERACTION)
// -------------------------------------------------------------
function renderSOSScreen() {
    return `
        <div class="space-y-3.5">
            <div class="bg-red-50 p-4 rounded-2xl border border-red-200 shadow-sm space-y-1">
                <span class="text-[10px] font-black uppercase tracking-wider text-red-800 bg-red-200/60 px-2 py-0.2 rounded font-mono">Zero-Carrier Mode Ready</span>
                <h2 class="text-base font-extrabold text-slate-900">Broadcast SOS Distress Signal</h2>
                <p class="text-xs text-slate-700 leading-relaxed">Transmits to NDRF 10th Battalion Command Room via BLE Mesh, Satellite & SMS.</p>
            </div>

            <div class="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3 text-xs">
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase block mb-1">Your Full Name & Family</label>
                    <input id="sos-name" type="text" value="${STATE.citizenProfile.name} (4 Members)" class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold">
                </div>
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase block mb-1">Emergency Situation</label>
                    <select id="sos-type" class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold">
                        <option value="Rising Flood Water (Trapped)">Rising Flood Water (Trapped on 1st Floor/Roof)</option>
                        <option value="Medical Critical Patient">Medical Critical (Oxygen/Insulin/Trauma)</option>
                        <option value="House Wall Collapse Hazard">House / Structural Collapse Hazard</option>
                        <option value="Stranded in Fast Current">Stranded in Fast River Current</option>
                    </select>
                </div>
                <div class="grid grid-cols-3 gap-2">
                    <label class="p-2 bg-slate-50 rounded-lg border border-slate-200 flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" id="sos-infant" checked class="w-4 h-4 text-red-600 rounded">
                        <span class="text-[10px] font-bold text-slate-700">Infant</span>
                    </label>
                    <label class="p-2 bg-slate-50 rounded-lg border border-slate-200 flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" id="sos-elderly" checked class="w-4 h-4 text-red-600 rounded">
                        <span class="text-[10px] font-bold text-slate-700">Elderly</span>
                    </label>
                    <label class="p-2 bg-slate-50 rounded-lg border border-slate-200 flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" id="sos-medical" checked class="w-4 h-4 text-red-600 rounded">
                        <span class="text-[10px] font-bold text-slate-700">Medical</span>
                    </label>
                </div>
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase block mb-1">Message / Landmarks</label>
                    <textarea id="sos-msg" rows="2" class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900" placeholder="e.g. Water at 6ft, red roof building near old bridge."></textarea>
                </div>

                <button onclick="submitSOSDistress()" class="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-extrabold text-xs shadow-lg flex items-center justify-center space-x-2 animate-pulse active:scale-95 transition">
                    <i data-lucide="radio" class="w-4 h-4"></i>
                    <span>Transmit Immediate SOS to NDRF Control</span>
                </button>
            </div>
        </div>
    `;
}

// -------------------------------------------------------------
// 6. NDRF AUTHORITY COMMAND ROOM
// -------------------------------------------------------------
function renderAuthorityScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-blue-950 text-white p-3 rounded-xl shadow flex items-center justify-between border border-blue-900">
                <div>
                    <h2 class="text-sm font-bold">NDRF Incident Command Center</h2>
                    <p class="text-[10px] text-blue-200">10th Battalion • Haridwar-Rishikesh Sector</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-red-600 text-white font-black animate-pulse">LIVE INCIDENT ROOM</span>
            </div>

            <div class="space-y-2 text-xs">
                ${STATE.sosQueue.map(s => `
                    <div class="p-3 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="font-extrabold text-slate-900">${s.userName}</span>
                            <span class="px-2 py-0.2 rounded text-[9px] font-mono font-bold bg-red-100 text-red-800">${s.id}</span>
                        </div>
                        <p class="text-[11px] text-slate-700 font-medium">📍 ${s.location} • 👥 ${s.peopleCount} Persons</p>
                        <p class="text-[11px] text-slate-900 bg-slate-50 p-2 rounded border border-slate-200">“${s.message}”</p>
                        <div class="flex items-center justify-between pt-1 text-[10px] text-slate-500">
                            <span>Assigned: <b class="text-blue-900">${s.assignedTeam}</b></span>
                            ${s.status === 'TEAM_EN_ROUTE' ? `
                                <span class="font-bold text-emerald-700">✓ EN ROUTE</span>
                            ` : `
                                <button onclick="assignRescueTeam('${s.id}')" class="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg shadow active:scale-95 transition">
                                    Dispatch Rescue Team
                                </button>
                            `}
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// -------------------------------------------------------------
// 7. OTHER SCREENS (MESH, CWC, BROADCAST, RECOVERY, SHELTERS, ALERTS)
// -------------------------------------------------------------
function renderMeshSimulatorScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Zero-Signal BLE Mesh Simulator</h2>
                    <p class="text-[10px] text-slate-500">Phone-to-Phone Multi-Hop Packet Relay</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-emerald-100 text-emerald-800 font-bold">5 Nodes Active</span>
            </div>

            <div class="bg-slate-900 text-white p-4 rounded-xl space-y-2.5 font-mono text-xs shadow">
                <div class="flex items-center justify-between border-b border-slate-700 pb-2">
                    <span class="text-emerald-400 font-bold">● BLE RADIO ONLINE</span>
                    <span class="text-slate-400 text-[10px]">Freq: 2.4 GHz • Ch 37/38/39</span>
                </div>
                <div class="space-y-1.5 text-[11px] text-slate-300">
                    <p>📡 [Node 0 (You)] ➔ Hopping packet through [Node 1 (Sector 4 Shop)]</p>
                    <p>📡 [Node 1] ➔ Hopped to [Node 2 (Temple Hill Base)]</p>
                    <p>🛰️ [Node 2] ➔ Uplinked via Satellite Gateway to NDRF Server!</p>
                </div>
                <div class="pt-2 border-t border-slate-700 flex justify-between text-[10px] text-slate-400">
                    <span>Packets Relayed: <b>142</b></span>
                    <span>Loss Rate: <b>0.0%</b></span>
                </div>
            </div>

            <button onclick="showToast('⚡ Transmitted Ping packet across 4 peer hops in 12ms!', 'success')" class="w-full py-2.5 bg-blue-900 text-white rounded-xl text-xs font-bold shadow hover:bg-blue-950 transition active:scale-95">
                Simulate Multi-Hop Packet Ping
            </button>
        </div>
    `;
}

function renderCwcTelemetryScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Central Water Commission (CWC) Grid</h2>
                    <p class="text-[10px] text-slate-500">Hydro-Meteorological Telemetry Sensors</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-blue-100 text-blue-800 font-bold">Active Station</span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span class="text-[10px] text-slate-500 uppercase font-bold">Gauge Water Level</span>
                    <p class="text-lg font-black text-red-600 font-mono">2.45 m</p>
                    <span class="text-[9px] text-red-700 font-bold">Danger Mark: 2.20 m (+25cm)</span>
                </div>
                <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
                    <span class="text-[10px] text-slate-500 uppercase font-bold">Discharge Rate</span>
                    <p class="text-lg font-black text-blue-900 font-mono">1,480 m³/s</p>
                    <span class="text-[9px] text-blue-700 font-bold">Surge Speed: 4.2 m/s</span>
                </div>
            </div>
        </div>
    `;
}

function renderBroadcastPreviewScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Multi-Channel Broadcast Preview</h2>
                    <p class="text-[10px] text-slate-500">Dialect Voice IVR + 2G Feature Phone SMS</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-orange-100 text-orange-800 font-bold">Garhwali / Hindi</span>
            </div>

            <div class="bg-white p-3.5 border border-slate-200 rounded-xl space-y-2 text-xs">
                <p class="font-bold text-slate-800 text-[10px] uppercase">Automated Voice Call (IVR Preview)</p>
                <div class="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-700 italic leading-relaxed">
                    “चेतावनी: गंगा नदी का जलस्तर खतरे के निशान से ऊपर है। कृपया तुरंत ऊंचे स्थानों पर जाएं। डायल 1078।”
                </div>
                <button onclick="showToast('🔊 Playing synthetic IVR voice siren in Garhwali...', 'info'); playSirenPulse();" class="w-full py-2 bg-orange-600 text-white rounded-lg font-bold text-xs hover:bg-orange-700 transition shadow">
                    ▶ Listen to Vernacular Audio Alert
                </button>
            </div>
        </div>
    `;
}

function renderRecoveryScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Anti-Hoarding Relief Kit Pass</h2>
                    <p class="text-[10px] text-slate-500">Aadhaar-Verified Ration & DBT Token</p>
                </div>
                <span class="px-2 py-0.5 rounded text-[9px] bg-purple-100 text-purple-800 font-bold">QR Authenticated</span>
            </div>

            <div class="bg-white p-5 border border-slate-200 rounded-2xl flex flex-col items-center text-center space-y-3 shadow-xs">
                <div class="p-3 bg-slate-900 rounded-2xl shadow text-white font-mono text-center">
                    <div class="w-36 h-36 bg-white p-2 rounded-xl flex items-center justify-center text-slate-900 text-5xl">
                        🏁
                    </div>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900">Token: RAKSHA-KIT-4321</h3>
                    <p class="text-xs text-slate-500">Beneficiary: <b>${STATE.citizenProfile.name}</b> • Family of 4</p>
                    <p class="text-[10px] text-emerald-700 font-bold mt-1">✓ Status: Claimed at Temple Hill Camp</p>
                </div>
            </div>
        </div>
    `;
}

function renderSheltersScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Verified Relief Camps & Shelters</h2>
                    <p class="text-[10px] text-slate-500">Live Bed & Medical Availability</p>
                </div>
            </div>

            <div class="space-y-2 text-xs">
                ${STATE.shelters.map(s => `
                    <div class="p-3 bg-white rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                        <div>
                            <h3 class="font-bold text-slate-900">${s.name}</h3>
                            <p class="text-[10px] text-slate-500">Elevation: <b>${s.elevation}m MSL</b> • Distance: <b>${s.distance}</b></p>
                            <span class="text-[9px] text-emerald-700 font-bold">Capacity: ${s.available} beds available</span>
                        </div>
                        <button onclick="navigate('evacuate')" class="px-3 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-bold hover:bg-emerald-800 shadow">
                            Route
                        </button>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderAlertsScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Disaster Warnings & Bulletins</h2>
                    <p class="text-[10px] text-slate-500">Ministry of Earth Sciences / IMD</p>
                </div>
            </div>

            <div class="space-y-2 text-xs">
                ${STATE.alerts.map(a => `
                    <div class="p-3.5 bg-white border border-slate-200 rounded-xl space-y-1.5 shadow-xs">
                        <div class="flex items-center justify-between">
                            <span class="px-2 py-0.2 rounded text-[9px] font-bold ${a.severity === 'CRITICAL' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}">${a.severity}</span>
                            <span class="text-[10px] text-slate-400 font-mono">${a.timeIssued}</span>
                        </div>
                        <h3 class="text-xs font-bold text-slate-900">${a.title}</h3>
                        <p class="text-[11px] text-slate-700 leading-relaxed">${a.instructions}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderFamilySafetyScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Family Safety Circle</h2>
                    <p class="text-[10px] text-slate-500">Live Status & Battery Telemetry</p>
                </div>
                <button onclick="showToast('✅ Safety broadcast pinged to all family members.', 'success')" class="px-2.5 py-1 bg-emerald-700 text-white rounded-lg text-xs font-bold shadow">
                    Ping All
                </button>
            </div>

            <div class="space-y-2 text-xs">
                ${STATE.familySafeStatus.map(f => `
                    <div class="p-3 bg-white rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                        <div class="flex items-center space-x-2.5">
                            <div class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                                ✓
                            </div>
                            <div>
                                <h3 class="font-bold text-slate-900">${f.name}</h3>
                                <p class="text-[10px] text-slate-500">📍 ${f.location} • Battery: <b>${f.battery}</b></p>
                            </div>
                        </div>
                        <span class="text-[10px] font-bold text-emerald-700">${f.time}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderEvacKitScreen() {
    return `
        <div class="space-y-3">
            <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                    <h2 class="text-sm font-bold text-slate-900">Evacuation Go-Bag Checklist</h2>
                    <p class="text-[10px] text-slate-500">Emergency Survival Kit Checklist</p>
                </div>
            </div>

            <div class="space-y-2 text-xs bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                ${STATE.evacChecklist.map(item => `
                    <label class="flex items-center space-x-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer">
                        <input type="checkbox" ${item.done ? 'checked' : ''} onchange="item.done = this.checked; showToast('Checklist updated.', 'info');" class="w-4 h-4 text-blue-900 rounded">
                        <span class="${item.done ? 'line-through text-slate-400' : 'font-medium text-slate-800'}">${item.text}</span>
                    </label>
                `).join('')}
            </div>
        </div>
    `;
}

// -------------------------------------------------------------
// MODALS: OTP VERIFICATION, DAY DETAILS & 24H HOURLY
// -------------------------------------------------------------
function openOtpVerificationModal() {
    const container = document.getElementById("modal-container");
    if (!container) return;

    container.innerHTML = `
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between">
                <h3 class="text-sm font-extrabold text-slate-900">Phone Number Verification</h3>
                <button onclick="closeModal()" class="text-slate-400 hover:text-slate-700 font-bold text-lg">&times;</button>
            </div>
            <p class="text-xs text-slate-600">Enter your registered Indian phone number for SMS and IVR disaster alerts.</p>
            <div class="space-y-2">
                <label class="text-[10px] font-bold text-slate-500 uppercase block">Mobile Number</label>
                <input id="otp-phone-input" type="tel" value="${STATE.citizenProfile.phone}" class="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-bold text-slate-900">
            </div>
            <div id="otp-code-section" class="hidden space-y-2">
                <label class="text-[10px] font-bold text-slate-500 uppercase block">Enter 6-Digit OTP</label>
                <input id="otp-code-input" type="text" placeholder="123456" maxlength="6" class="w-full text-center tracking-widest text-base font-black bg-slate-50 border border-slate-300 rounded-lg p-2 text-blue-900 font-mono">
                <p class="text-[10px] text-emerald-700 font-bold">Demo OTP sent: <span id="demo-otp-val">123456</span></p>
            </div>
            <div class="flex space-x-2 pt-1">
                <button id="otp-action-btn" onclick="sendOtpCode()" class="w-full py-2 bg-blue-900 text-white rounded-xl text-xs font-bold hover:bg-blue-950 shadow">
                    Send Verification OTP
                </button>
            </div>
        </div>
    `;
    container.classList.remove("hidden");
    container.classList.add("flex");
}

function sendOtpCode() {
    const phone = document.getElementById("otp-phone-input").value;
    STATE.citizenProfile.phone = phone;
    document.getElementById("otp-code-section").classList.remove("hidden");
    const actionBtn = document.getElementById("otp-action-btn");
    actionBtn.innerText = "Verify OTP & Confirm";
    actionBtn.onclick = verifyOtpCode;
    showToast(`OTP Code sent to ${phone}`, "success");
}

function verifyOtpCode() {
    const code = document.getElementById("otp-code-input").value;
    if (code && code.length >= 4) {
        STATE.citizenProfile.isPhoneVerified = true;
        saveSettingsToStorage();
        closeModal();
        showToast("✅ Mobile Number Successfully Verified!", "success");
        navigate("profile");
    } else {
        showToast("Please enter a valid OTP.", "critical");
    }
}

function showDayDetailModal(index) {
    const day = STATE.dailyForecast[index];
    if (!day) return;

    const container = document.getElementById("modal-container");
    if (!container) return;

    container.innerHTML = `
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 space-y-3.5 shadow-2xl">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                    <h3 class="text-sm font-extrabold text-slate-900">${day.dayName} (${day.dateFormatted})</h3>
                    <p class="text-[10px] text-slate-500">${day.weatherText}</p>
                </div>
                <button onclick="closeModal()" class="text-slate-400 hover:text-slate-700 font-bold text-lg">&times;</button>
            </div>

            <div class="grid grid-cols-2 gap-2 text-center text-xs">
                <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span class="text-[9px] text-slate-500 font-bold uppercase block">Max / Min Temp</span>
                    <span class="text-sm font-black text-slate-900 font-mono">${day.maxTemp}°C / ${day.minTemp}°C</span>
                </div>
                <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span class="text-[9px] text-slate-500 font-bold uppercase block">Rain Probability</span>
                    <span class="text-sm font-black text-blue-900 font-mono">${day.rainProb}%</span>
                </div>
                <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span class="text-[9px] text-slate-500 font-bold uppercase block">Expected Rain</span>
                    <span class="text-sm font-black text-blue-900 font-mono">${day.rainSum} mm</span>
                </div>
                <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span class="text-[9px] text-slate-500 font-bold uppercase block">Max Wind Gusts</span>
                    <span class="text-sm font-black text-slate-900 font-mono">${day.windMax} km/h</span>
                </div>
            </div>

            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span class="text-[9px] font-bold text-slate-500 uppercase">Recommended Precautions</span>
                <p class="text-xs text-slate-900 font-medium">${day.precaution}</p>
            </div>

            <button onclick="closeModal()" class="w-full py-2 bg-blue-900 text-white rounded-xl text-xs font-bold shadow hover:bg-blue-950">
                Close
            </button>
        </div>
    `;
    container.classList.remove("hidden");
    container.classList.add("flex");
    lucide.createIcons();
}

function showHourlyForecastModal() {
    const container = document.getElementById("modal-container");
    if (!container) return;

    container.innerHTML = `
        <div class="bg-white rounded-2xl max-w-md w-full p-4 space-y-3 shadow-2xl max-h-[85vh] flex flex-col">
            <div class="flex items-center justify-between pb-2 border-b border-slate-100">
                <h3 class="text-sm font-extrabold text-slate-900">24-Hour Hourly Nowcast Breakdown</h3>
                <button onclick="closeModal()" class="text-slate-400 hover:text-slate-700 font-bold text-lg">&times;</button>
            </div>
            
            <div class="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar text-xs">
                ${STATE.hourlyForecast.map(h => `
                    <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                        <div class="w-14 font-mono font-bold text-slate-700">${h.time}</div>
                        <div class="flex items-center space-x-2 flex-1 px-2">
                            <i data-lucide="${h.weatherIcon}" class="w-4 h-4 text-blue-900"></i>
                            <span class="text-[11px] text-slate-600 truncate">${h.weatherText}</span>
                        </div>
                        <div class="text-right">
                            <span class="font-bold text-slate-900 font-mono">${h.temp}°C</span>
                            <div class="text-[9px] font-bold text-blue-800">${h.rainProb}% Rain (${h.rainMm}mm)</div>
                        </div>
                    </div>
                `).join('')}
            </div>

            <button onclick="closeModal()" class="w-full py-2 bg-blue-900 text-white rounded-xl text-xs font-bold shadow hover:bg-blue-950">
                Close
            </button>
        </div>
    `;
    container.classList.remove("hidden");
    container.classList.add("flex");
    lucide.createIcons();
}

function closeModal() {
    const container = document.getElementById("modal-container");
    if (container) {
        container.classList.add("hidden");
        container.classList.remove("flex");
    }
}

function toggleSetting(key, val) {
    STATE.settings[key] = val;
    saveSettingsToStorage();
    showToast(`Updated ${key} preference.`, "success");
}

function testMultiChannelAlertDispatch() {
    showToast("🚀 Dispatching Multi-Channel Test Alert...", "info");
    const testRecord = {
        id: `TEST-${Date.now().toString().slice(-3)}`,
        title: "CRITICAL: Severe Weather Test Advisory",
        severity: "CRITICAL",
        area: "Your Current Sector",
        instructions: "This is a test of In-App, FCM Push, SMS & IVR channels."
    };
    if (STATE.isAuthority) {
        triggerAdminIncidentNotification(testRecord);
    } else {
        showToast("✅ Test alert logged to Delivery History.", "success");
    }
}

async function handleLocationSearch(query) {
    if (!query || query.trim().length < 2) return;
    showToast(`🔍 Locating "${query}"...`, "info");
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=5&language=en&format=json`;
    try {
        const r = await fetch(url);
        const data = await r.json();
        if (data.results && data.results.length > 0) {
            const item = data.results[0];
            const fullName = `${item.name}, ${item.admin1 || item.admin2 || ""}, ${item.country || "India"}`.replace(/,\s*,/g, ',').trim();
            await fetchLiveOpenMeteo(item.latitude, item.longitude, fullName);
            showToast(`📍 Live Location Set: ${fullName}`, "success");
        } else {
            showToast(`Location "${query}" not found. Try nearest district/city.`, "critical");
        }
    } catch (e) {
        showToast("Search error: Could not reach geocoding service.", "critical");
    }
}

async function detectDeviceGPS(autoBoot = false) {
    if (!autoBoot) showToast("📍 Acquiring exact device GPS position...", "info");
    
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
            async pos => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;
                const locName = await reverseGeocode(lat, lng);
                await fetchLiveOpenMeteo(lat, lng, locName);
                if (!autoBoot) showToast(`📍 Live GPS Position Loaded: ${locName}`, "success");
            },
            async err => {
                console.warn("GPS direct permission failed or denied:", err.message);
                // Fallback to IP Geolocation to automatically get user's real Indian city
                try {
                    const ipRes = await fetch("https://ipapi.co/json/");
                    if (ipRes.ok) {
                        const ipData = await ipRes.json();
                        if (ipData.latitude && ipData.longitude) {
                            const fullName = `${ipData.city || ipData.region || "Metro"}, ${ipData.region || ""}, ${ipData.country_name || "India"}`;
                            await fetchLiveOpenMeteo(ipData.latitude, ipData.longitude, fullName);
                            if (!autoBoot) showToast(`📍 Auto-Detected Location: ${fullName}`, "success");
                            return;
                        }
                    }
                } catch(e) {}
                
                if (!autoBoot) showToast("GPS permission denied. Using selected region.", "info");
                await fetchLiveOpenMeteo(STATE.userCoords[0], STATE.userCoords[1], STATE.currentLocationName, true);
            },
            { enableHighAccuracy: true, timeout: 6000, maximumAge: 30000 }
        );
    } else {
        try {
            const ipRes = await fetch("https://ipapi.co/json/");
            if (ipRes.ok) {
                const ipData = await ipRes.json();
                if (ipData.latitude && ipData.longitude) {
                    const fullName = `${ipData.city || ipData.region}, ${ipData.region || ""}, ${ipData.country_name || "India"}`;
                    await fetchLiveOpenMeteo(ipData.latitude, ipData.longitude, fullName);
                    return;
                }
            }
        } catch(e) {}
        await fetchLiveOpenMeteo(STATE.userCoords[0], STATE.userCoords[1], STATE.currentLocationName, true);
    }
}

function showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const colors = {
        success: "bg-emerald-800 text-white",
        critical: "bg-red-700 text-white",
        info: "bg-blue-900 text-white"
    };

    const toast = document.createElement("div");
    toast.className = `p-3 rounded-xl shadow-lg text-[11px] font-bold max-w-sm ${colors[type] || colors.info} flex items-center justify-between space-x-2 pointer-events-auto`;
    toast.innerHTML = `
        <div class="flex items-center space-x-2">
            <span>${message}</span>
        </div>
        <button onclick="this.parentElement.remove()" class="text-white/80 hover:text-white text-sm">&times;</button>
    `;

    container.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 4000);
}
